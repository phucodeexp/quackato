const TELE_USER = require("./token.json");
const ACCESS_TOKEN = TELE_USER.state.token;

let listColect = [];
let listDuck = [];
let isLiveGame = false;

Array.prototype.random = function () {
  return this[Math.floor(Math.random() * this.length)];
};

async function checkLiveGame() {
  isLiveGame = true;
  return isLiveGame;
}

async function getTotalEgg() {
  if (!isLiveGame) return console.log(`Game sập r dm`);

  try {
    let response = await fetch("https://api.quackquack.games/balance/get", {
      headers: {
        accept: "*/*",
        "accept-language": "en-US,en;q=0.9,vi;q=0.8",
        authorization: "Bearer " + ACCESS_TOKEN,
        priority: "u=1, i",
        "sec-ch-ua":
          '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "cross-site",
        Referer: "https://dd42189ft3pck.cloudfront.net/",
        "Referrer-Policy": "strict-origin-when-cross-origin",
      },
      body: null,
      method: "GET",
    });
    let data = await response.json();
    // console.log(data);
    if (data.error_code !== "") console.log(data.error_code);

    console.log(`-----------------------------------`);
    data.data.data.map((item) => {
      if (item.symbol === "PET")
        console.log(`bạn đang có : ${item.balance} PEPET`);
      if (item.symbol === "EGG")
        console.log(`bạn đang có: ${item.balance} EGG`);
    });
    console.log(`-----------------------------------`);
  } catch (error) {
    console.log("getTotalEgg error:", error);
    setTimeout(getTotalEgg, 3e3);
  }
}

async function getListCollectEgg() {
  if (!isLiveGame) return console.log(`Game sap cmnr`);

  try {
    await getTotalEgg();

    let response = await fetch(
      "https://api.quackquack.games/nest/list-reload",
      {
        headers: {
          accept: "*/*",
          "accept-language": "en-US,en;q=0.9,vi;q=0.8",
          authorization: "Bearer " + ACCESS_TOKEN,
          priority: "u=1, i",
          "sec-ch-ua":
            '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": '"Windows"',
          "sec-fetch-dest": "empty",
          "sec-fetch-mode": "cors",
          "sec-fetch-site": "cross-site",
          Referer: "https://dd42189ft3pck.cloudfront.net/",
          "Referrer-Policy": "strict-origin-when-cross-origin",
        },
        body: null,
        method: "GET",
      }
    );
    let data = await response.json();
    // console.log(data);
    if (data.error_code !== "") console.log(data.error_code);

    if (listDuck.length === 0) {
      data.data.duck.map((item) => {
        // console.log(item);
        listDuck.push(item);
      });
    }

    data.data.nest.map((item) => {
      // console.log(item);
      if (item.type_egg) listColect.push(item);
    });

    let eggs = listColect.map((i) => i.id);

    if (listColect.length > 0) {
      console.log(`Trung co the thu thap: ${listColect.length}`, eggs);
      collect();
    }
  } catch (error) {
    console.log("getListCollectEgg error:", error);
    setTimeout(getListCollectEgg, 3e3);
  }
}

async function collect() {
  if (!isLiveGame) return console.log(`Game sap cmnr`);

  try {
    if (listColect.length === 0) return getListCollectEgg();

    const egg = listColect[0];
    // console.log(egg);

    let response = await fetch("https://api.quackquack.games/nest/collect", {
      headers: {
        accept: "*/*",
        "accept-language": "en-US,en;q=0.9,vi;q=0.8",
        authorization: "Bearer " + ACCESS_TOKEN,
        "content-type": "application/x-www-form-urlencoded",
        priority: "u=1, i",
        "sec-ch-ua":
          '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "cross-site",
        Referer: "https://dd42189ft3pck.cloudfront.net/",
        "Referrer-Policy": "strict-origin-when-cross-origin",
      },
      body: "nest_id=" + egg.id,
      method: "POST",
    });
    let data = await response.json();
    // console.log(data);
    // if (data.error_code !== "") console.log(data.error_code);
    return layEgg(egg);
  } catch (error) {
    console.log("collect error:", error);
    setTimeout(collect, 3e3);
  }
}

async function layEgg(egg) {
  if (!isLiveGame) return console.log(`Game sap cmnr`);

  try {
    const duck = listDuck.random();
    // console.log(`${duck.id}:${egg.id}`);

    let response = await fetch("https://api.quackquack.games/nest/lay-egg", {
      headers: {
        accept: "*/*",
        "accept-language": "en-US,en;q=0.9,vi;q=0.8",
        authorization: "Bearer " + ACCESS_TOKEN,
        "content-type": "application/x-www-form-urlencoded",
        priority: "u=1, i",
        "sec-ch-ua":
          '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "cross-site",
        Referer: "https://dd42189ft3pck.cloudfront.net/",
        "Referrer-Policy": "strict-origin-when-cross-origin",
      },
      body: "nest_id=" + egg.id + "&duck_id=" + duck.id,
      method: "POST",
    });
    let data = await response.json();
    // console.log(data);
    if (data.error_code !== "") console.log(data.error_code);

    console.log(`trứng nè ${egg.id}`);
    listColect.shift();
    setTimeout(collect, 3e3);
  } catch (error) {
    console.log("layEgg error:", error);
    setTimeout(() => layEgg(egg), 3e3);
  }
}

console.log();
console.log(`fb ad:phutran205`);

setInterval(() => console.clear(), 6e5);

checkLiveGame().then(getGoldDuckInfo).then(getListCollectEgg);

// keepAlive();
// setInterval(keepAlive, 6e5);

async function getGoldDuckInfo() {
  if (!isLiveGame) return console.log(`Game sap cmnr`);

  try {
    let response = await fetch(
      "https://api.quackquack.games/golden-duck/info",
      {
        headers: {
          accept: "*/*",
          "accept-language": "en-US,en;q=0.9,vi;q=0.8",
          authorization: "Bearer " + ACCESS_TOKEN,
          priority: "u=1, i",
          "sec-ch-ua":
            '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": '"Windows"',
          "sec-fetch-dest": "empty",
          "sec-fetch-mode": "cors",
          "sec-fetch-site": "cross-site",
          Referer: "https://dd42189ft3pck.cloudfront.net/",
          "Referrer-Policy": "strict-origin-when-cross-origin",
        },
        body: null,
        method: "GET",
      }
    );
    let data = await response.json();
    // console.log(data);
    //   {
    //     "error_code": "",
    //     "data": {
    //         "status": 1,
    //         "time_to_golden_duck": 0,
    //         "timestamp": 1716684105
    //     }
    // }

    //   {
    //     "error_code": "",
    //     "data": {
    //         "status": 2,
    //         "time_to_golden_duck": 1796,
    //         "timestamp": 1716684112
    //     }
    // }

    if (data.error_code !== "") console.log(data.error_code);

    console.log(``);
    if (data.data.time_to_golden_duck === 0) {
      console.log(`VIT VANG : Xin chao`);
      getGoldDuckReward();
    } else {
      let nextGoldDuck = data.data.time_to_golden_duck;
      console.log(
        `VIT VANG : ${Number(nextGoldDuck / 60).toFixed(0)} phut nua gap`
      );
      console.log(``);
      setTimeout(getGoldDuckInfo, nextGoldDuck * 1e3);
    }
  } catch (error) {
    console.log("getGoldDuckInfo error", error);
  }
}

async function getGoldDuckReward() {
  if (!isLiveGame) return console.log(`Game sap cmnr`);

  try {
    let response = await fetch(
      "https://api.quackquack.games/golden-duck/reward",
      {
        headers: {
          accept: "*/*",
          "accept-language": "en-US,en;q=0.9,vi;q=0.8",
          authorization: "Bearer " + ACCESS_TOKEN,
          priority: "u=1, i",
          "sec-ch-ua":
            '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": '"Windows"',
          "sec-fetch-dest": "empty",
          "sec-fetch-mode": "cors",
          "sec-fetch-site": "cross-site",
          Referer: "https://dd42189ft3pck.cloudfront.net/",
          "Referrer-Policy": "strict-origin-when-cross-origin",
        },
        body: null,
        method: "GET",
      }
    );
    let data = await response.json();
    // console.log(data);
    // {"error_code":"","data":{"type":3,"amount":"500.00"}}

    if (data.error_code !== "") console.log(data.error_code);

    if (data.data.type === 0) {
      console.log(`VIT VANG : Chuc ban may man lan sau`);
      getGoldDuckInfo();
    }

    if (data.data.type === 2 || data.data.type === 3) claimGoldDuck(data.data);
  } catch (error) {
    console.log("getGoldDuckReward error", error);
  }
}

async function claimGoldDuck(gDuck) {
  if (!isLiveGame) return console.log(`Game sap cmnr`);

  try {
    let response = await fetch(
      "https://api.quackquack.games/golden-duck/claim",
      {
        headers: {
          accept: "*/*",
          "accept-language": "en-US,en;q=0.9,vi;q=0.8",
          authorization: "Bearer " + ACCESS_TOKEN,
          "content-type": "application/x-www-form-urlencoded",
          priority: "u=1, i",
          "sec-ch-ua":
            '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": '"Windows"',
          "sec-fetch-dest": "empty",
          "sec-fetch-mode": "cors",
          "sec-fetch-site": "cross-site",
          Referer: "https://dd42189ft3pck.cloudfront.net/",
          "Referrer-Policy": "strict-origin-when-cross-origin",
        },
        body: "type=1",
        method: "POST",
      }
    );
    let data = await response.json();
    // console.log(data);
    // {"error_code":"","data":true}
    if (data.error_code !== "") console.log(data.error_code);
    let info = infoGoldDuck(gDuck);
    console.log(`VIT VANG : ${info.amount} ${info.label}`);
    getGoldDuckInfo();
  } catch (error) {
    console.log("claimGoldDuck error", error);
  }
}

function infoGoldDuck(data) {
  if (data.type === 1) return { label: "TON", amount: data.amount };
  if (data.type === 2) return { label: "PEPET", amount: data.amount };
  if (data.type === 3) return { label: "EGG", amount: data.amount };
  if (data.type === 4) return { label: "TRU", amount: data.amount };
}

async function keepAlive() {
  try {
  } catch (error) {
    console.log("keepAlive error", error);
  }
}
