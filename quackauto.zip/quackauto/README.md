#  Tool tự động nhặt trứng Quack Quack Game

* Windows / Mac / Linux đều dùng được miễn có cài NodeJS > Link tải: https://nodejs.org/en/download/prebuilt-installer

* Phải mở song song cửa sổ Quack Game và Tool để chạy ổn định

* 1 cửa sổ Quack Game chạy song song với 1 cửa sổ Tool, muốn thêm tài khoản thì tạo thêm Profile trình truyệt để mở Quack Game và mở thêm cửa sổ Tool

* Thu nhỏ các cửa sổ lại cho đỡ tốn tài nguyên xíu

* Đây công cụ mình làm ra để thử sức code nên code đơn giản và chỉ update tính năng khi rảnh rổi. Vì công việc chính của tui là sửa laptop chứ không phải dev mấy má ưi 😍

## Lịch sử cập nhật

> 12:00 - 26/05/2024: Sửa lỗi ở bản update trước, thêm tự lụm Bạch Tuột hay Vịt Vàng gì đó

> 02:00 - 26/05/2024: Tạo tệp token.txt để thêm token dễ hơn, thay đổi cách code để lụm trứng mượt hơn, sửa hướng dẫn cụ thể hơn

> 23/05/2024: Khởi tạo, phải bỏ token trực tiếp vào code nên hơi khó dùng, cách code còn dở


## Bước 1: Lấy ACCESS_TOKEN

<img src="./imgs/1.png" />

> Đăng nhập Telegram Web trên Google Chrome > mở Quack Quack game > mở Dev Tools (ctrl + shift + i) > tab Application > Local storage

> Click vào dòng: play.quackquack.games > click vào dòng: telegram-user

> Click chuột phải vào cột kế bên nó > Edit "Value" > Click chuột phải vào nó lần nữa và Copy

> Mở file token > paste vào rồi lưu lại

> Token sẽ hết hạn sau 5 ngày, khi game có cập nhật hoặc khi Tool báo lỗi liên tục và không thu thập được trứng thì phải lấy token mới

## Bước 2: Khởi chạy

<img src="./imgs/2.png" />

> Mở Terminal hoặc PowerShell trong folder mã nguồn:

> Đè phím Shift + click chuột phải sẽ thấy tùy chọn mở

> Gõ vào Terminal/PowerShell dòng code này:

```sh
node quack
```

<img src="./imgs/3.png" />

> Tự động lụm Tuột Dịt Dàng 🤣

<img src="./imgs/4.png" />

## Video hướng dẫn chạy trên Windows:

> https://www.tiktok.com/@mhqb365/video/7373169718821260561

Mọi người có hứng thú con game vô tri này thì đăng ký qua link ủng hộ mình nhé: https://t.me/quackquack_game_bot?start=6hn8Xrp7DK

From https://mhqb365.com with ♥
